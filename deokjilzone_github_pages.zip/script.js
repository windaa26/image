
const produk = [
  { nama: "Keyring Truz", harga: 75000, genre: "pertumbuhan", gambar: "img/keyring.jpg", deskripsi: "Gantungan kunci lucu karakter Truz!" },
  { nama: "Seventeen Doll Meniteen", harga: 210000, genre: "remaja", gambar: "img/doll.jpg", deskripsi: "Boneka Meniteen Seventeen, lembut dan imut!" },
  { nama: "Hand Banner Seventeen", harga: 85000, genre: "energi", gambar: "img/banner.jpg", deskripsi: "Spanduk tangan untuk mendukung Seventeen!" }
];

function tampilkanProduk() {
  const container = document.getElementById("productContainer");
  container.innerHTML = "";
  const genre = document.getElementById("genreFilter").value;
  const price = document.getElementById("priceFilter").value;
  const search = document.getElementById("searchInput").value.toLowerCase();
  const hasilFilter = produk.filter(p => {
    const cocokGenre = genre === "all" || p.genre === genre;
    const cocokHarga = price === "all" ||
      (price === "low" && p.harga < 180000) ||
      (price === "mid" && p.harga >= 180000 && p.harga <= 210000) ||
      (price === "high" && p.harga > 210000);
    const cocokCari = p.nama.toLowerCase().includes(search);
    return cocokGenre && cocokHarga && cocokCari;
  });

  hasilFilter.forEach((p, i) => {
    const card = document.createElement("div");
    card.className = "produk-item";
    card.innerHTML = `
      <img src="\${p.gambar}" alt="\${p.nama}" />
      <h3>\${p.nama}</h3>
      <p>\${p.deskripsi}</p>
      <p class="harga">Rp \${p.harga.toLocaleString()}</p>
      <button onclick="tambahKeKeranjang(\${i})">+ Keranjang</button>
    `;
    container.appendChild(card);
  });
}

function filterProduk() { tampilkanProduk(); }
document.getElementById("genreFilter").addEventListener("change", tampilkanProduk);
document.getElementById("priceFilter").addEventListener("change", tampilkanProduk);
let keranjang = [];
function tambahKeKeranjang(i) { keranjang.push(produk[i]); alert("Ditambahkan ke keranjang!"); }
function bukaKeranjang() { document.getElementById("cartModal").style.display = "block"; }
function tutupKeranjang() { document.getElementById("cartModal").style.display = "none"; }
function bukaLogin() { document.getElementById("loginModal").style.display = "block"; }
function tutupLogin() { document.getElementById("loginModal").style.display = "none"; }
function loginSimulasi() { alert("Login berhasil!"); tutupLogin(); return false; }
window.onload = tampilkanProduk;
